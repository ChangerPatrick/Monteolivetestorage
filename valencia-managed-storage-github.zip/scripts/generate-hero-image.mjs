import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { deflateSync } from "node:zlib";

const width = 1440;
const height = 980;
const channels = 4;
const pixels = Buffer.alloc(width * height * channels);

const hexToRgba = (hex, alpha = 255) => {
  const value = hex.replace("#", "");
  return [
    Number.parseInt(value.slice(0, 2), 16),
    Number.parseInt(value.slice(2, 4), 16),
    Number.parseInt(value.slice(4, 6), 16),
    alpha
  ];
};

const putPixel = (x, y, rgba) => {
  if (x < 0 || y < 0 || x >= width || y >= height) {
    return;
  }

  const index = (y * width + x) * channels;
  const alpha = rgba[3] / 255;
  pixels[index] = Math.round(rgba[0] * alpha + pixels[index] * (1 - alpha));
  pixels[index + 1] = Math.round(rgba[1] * alpha + pixels[index + 1] * (1 - alpha));
  pixels[index + 2] = Math.round(rgba[2] * alpha + pixels[index + 2] * (1 - alpha));
  pixels[index + 3] = 255;
};

const fillRoundedRect = (x, y, w, h, radius, color, alpha = 255) => {
  const rgba = hexToRgba(color, alpha);
  const r = Math.max(0, Math.min(radius, Math.floor(Math.min(w, h) / 2)));
  for (let row = y; row < y + h; row += 1) {
    for (let col = x; col < x + w; col += 1) {
      const dx = col < x + r ? x + r - col : col >= x + w - r ? col - (x + w - r - 1) : 0;
      const dy = row < y + r ? y + r - row : row >= y + h - r ? row - (y + h - r - 1) : 0;
      if (dx * dx + dy * dy <= r * r || dx === 0 || dy === 0) {
        putPixel(col, row, rgba);
      }
    }
  }
};

const drawShelf = (x, y, w, h) => {
  fillRoundedRect(x, y, w, h, 12, "#ffffff", 250);
  fillRoundedRect(x + 24, y + 24, w - 48, 18, 8, "#24313f", 35);
  fillRoundedRect(x + 24, y + h - 44, w - 48, 18, 8, "#24313f", 35);

  const shelves = 3;
  const shelfGap = Math.floor((h - 110) / shelves);
  for (let i = 0; i < shelves; i += 1) {
    const shelfY = y + 78 + i * shelfGap;
    fillRoundedRect(x + 34, shelfY + 126, w - 68, 14, 7, "#197b85", 160);

    const boxColors = ["#f3b23c", "#c86b3c", "#7e9a52", "#197b85", "#f5d7a5", "#dfe8ed"];
    let cursor = x + 52;
    for (let b = 0; b < 4; b += 1) {
      const boxW = 86 + ((i + b) % 3) * 28;
      const boxH = 72 + ((i * 2 + b) % 3) * 18;
      const boxY = shelfY + 126 - boxH;
      fillRoundedRect(cursor + 7, boxY + 9, boxW, boxH, 8, "#24313f", 18);
      fillRoundedRect(cursor, boxY, boxW, boxH, 8, boxColors[(i + b) % boxColors.length], 235);
      fillRoundedRect(cursor + 16, boxY + 18, boxW - 32, 12, 5, "#ffffff", 175);
      fillRoundedRect(cursor + 16, boxY + 42, Math.max(24, boxW - 54), 8, 4, "#ffffff", 110);
      cursor += boxW + 26;
    }
  }
};

const drawVan = (x, y) => {
  fillRoundedRect(x, y, 300, 130, 18, "#ffffff", 245);
  fillRoundedRect(x + 28, y + 28, 104, 44, 8, "#dcebf0", 255);
  fillRoundedRect(x + 148, y + 28, 78, 44, 8, "#dcebf0", 255);
  fillRoundedRect(x + 238, y + 54, 42, 18, 8, "#197b85", 210);
  fillRoundedRect(x + 34, y + 94, 48, 48, 24, "#24313f", 230);
  fillRoundedRect(x + 206, y + 94, 48, 48, 24, "#24313f", 230);
  fillRoundedRect(x + 48, y + 108, 20, 20, 10, "#ffffff", 255);
  fillRoundedRect(x + 220, y + 108, 20, 20, 10, "#ffffff", 255);
  fillRoundedRect(x + 104, y + 88, 84, 16, 8, "#c86b3c", 230);
};

const crcTable = new Uint32Array(256).map((_, n) => {
  let c = n;
  for (let k = 0; k < 8; k += 1) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  return c >>> 0;
});

const crc32 = (buffer) => {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
};

const chunk = (type, data) => {
  const typeBuffer = Buffer.from(type);
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])));
  return Buffer.concat([length, typeBuffer, data, crc]);
};

const writePng = (path) => {
  const raw = Buffer.alloc((width * channels + 1) * height);
  for (let y = 0; y < height; y += 1) {
    const rowStart = y * (width * channels + 1);
    raw[rowStart] = 0;
    pixels.copy(raw, rowStart + 1, y * width * channels, (y + 1) * width * channels);
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const png = Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0))
  ]);

  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, png);
};

for (let y = 0; y < height; y += 1) {
  for (let x = 0; x < width; x += 1) {
    const t = y / height;
    const r = Math.round(248 - t * 15);
    const g = Math.round(251 - t * 22);
    const b = Math.round(250 - t * 18);
    putPixel(x, y, [r, g, b, 255]);
  }
}

fillRoundedRect(72, 86, 1296, 790, 32, "#ffffff", 215);
fillRoundedRect(106, 120, 1228, 724, 28, "#eef5f3", 255);
fillRoundedRect(112, 610, 1216, 190, 16, "#dde8e6", 255);

for (let i = 0; i < 12; i += 1) {
  fillRoundedRect(128 + i * 102, 606 - i * 4, 74, 320 + i * 8, 22, "#ffffff", 56);
}

drawShelf(156, 174, 430, 524);
drawShelf(620, 146, 478, 596);

fillRoundedRect(965, 236, 244, 300, 18, "#ffffff", 235);
fillRoundedRect(996, 270, 86, 88, 12, "#197b85", 220);
fillRoundedRect(1102, 270, 78, 88, 12, "#f3b23c", 230);
fillRoundedRect(996, 382, 184, 22, 8, "#24313f", 45);
fillRoundedRect(996, 426, 138, 18, 8, "#24313f", 35);
fillRoundedRect(996, 468, 170, 18, 8, "#24313f", 35);

drawVan(922, 642);
fillRoundedRect(170, 756, 628, 58, 20, "#24313f", 28);
fillRoundedRect(204, 744, 174, 54, 12, "#ffffff", 235);
fillRoundedRect(404, 744, 168, 54, 12, "#ffffff", 235);
fillRoundedRect(598, 744, 168, 54, 12, "#ffffff", 235);
fillRoundedRect(228, 765, 116, 12, 6, "#197b85", 190);
fillRoundedRect(428, 765, 102, 12, 6, "#c86b3c", 190);
fillRoundedRect(622, 765, 104, 12, 6, "#7e9a52", 190);

writePng(join(process.cwd(), "public", "storage-hub-hero.png"));
