import type { Metadata } from "next";
import { LockKeyhole, Mail, MessageCircle, MonitorCog, UserRound } from "lucide-react";
import { AdminDemoDashboard } from "@/components/AdminDemoDashboard";
import { CTAButton } from "@/components/CTAButton";
import { SectionHeader } from "@/components/SectionHeader";
import { siteKeywords } from "@/data/storage";
import {
  adminEmail,
  adminName,
  adminPhoneDisplay,
  businessName
} from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  title: "Admin Demo",
  description: `Mock admin dashboard demo for ${businessName} quote requests, stored item inventory, item statuses, warehouse locations, and filters.`,
  keywords: siteKeywords
};

export default function AdminDemoPage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1fr_0.75fr] lg:items-end">
          <SectionHeader
            eyebrow="Admin demo"
            title="Mock operations dashboard"
            description="This page is not protected and uses local mock data only. It shows how staff could review quote requests, track item status, and locate stored items inside the managed storage hub."
          />
          <div className="space-y-4">
            <div className="rounded-lg border border-harbor/20 bg-white p-5 shadow-sm">
              <div className="flex gap-3">
                <UserRound aria-hidden="true" className="mt-1 h-5 w-5 shrink-0 text-harbor" />
                <div>
                  <h2 className="text-xl font-bold text-ink">{adminName}</h2>
                  <p className="mt-1 text-sm font-bold text-harbor">Storage Manager</p>
                  <p className="mt-4 flex gap-2 text-sm leading-6 text-slate-700">
                    <Mail aria-hidden="true" className="mt-1 h-4 w-4 shrink-0 text-clay" />
                    <span>{adminEmail}</span>
                  </p>
                  <p className="flex gap-2 text-sm leading-6 text-slate-700">
                    <MessageCircle aria-hidden="true" className="mt-1 h-4 w-4 shrink-0 text-clay" />
                    <span>{adminPhoneDisplay}</span>
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-lg border border-clay/25 bg-white p-5 shadow-sm">
              <div className="flex gap-3">
                <LockKeyhole aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-clay" />
                <p className="text-sm leading-6 text-slate-700">
                  Demo only. No login, no database, no real customer records, and no operational permissions are connected.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <AdminDemoDashboard />
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl rounded-lg border border-harbor/20 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex gap-4">
              <MonitorCog aria-hidden="true" className="mt-1 h-7 w-7 shrink-0 text-harbor" />
              <div>
                <h2 className="text-2xl font-bold tracking-normal text-ink">Customer view demo</h2>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
                  Compare this staff dashboard with the future customer-facing item inventory view.
                </p>
              </div>
            </div>
            <CTAButton href="/my-items-demo" variant="outline" className="shrink-0">
              View My Items demo
            </CTAButton>
          </div>
        </div>
      </section>
    </>
  );
}
