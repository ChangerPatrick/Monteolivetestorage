import type { Metadata } from "next";
import { Building2, Camera, KeyRound, MapPinned, ShieldCheck, Tags } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { SectionHeader } from "@/components/SectionHeader";
import { siteKeywords } from "@/data/storage";
import { businessName } from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  title: "About",
  description: `About ${businessName}, a local managed-storage service concept in Monteolivete and nearby Valencia neighborhoods.`,
  keywords: siteKeywords
};

const principles = [
  {
    title: "Local Valencia service",
    description: "A managed storage hub concept focused first on Monteolivete and nearby neighborhoods.",
    icon: MapPinned
  },
  {
    title: "Staff-managed storage zone",
    description: "Customers do not access the storage zone. Staff manage receiving, organization, and returns.",
    icon: KeyRound
  },
  {
    title: "Photographed and labeled items",
    description: "Items are received, photographed, labeled, and tracked as an internal inventory.",
    icon: Camera
  },
  {
    title: "Trust and organization",
    description: "The model is built around clear records, careful handling, and convenient item return.",
    icon: ShieldCheck
  }
];

export default function AboutPage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="About"
            title="A local Valencia managed-storage service"
            description={`${businessName} combines commercial property with an online storage platform. Customers store specific items, not a private room.`}
          />
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-start">
          <div className="rounded-lg border border-slate-200 bg-mist p-6">
            <Building2 aria-hidden="true" className="h-8 w-8 text-clay" />
            <h2 className="mt-5 text-2xl font-bold tracking-normal text-ink">
              First hub concept in Monteolivete
            </h2>
            <p className="mt-4 text-sm leading-6 text-slate-600">
              The MVP focuses on Monteolivete and nearby Valencia neighborhoods, with a practical service for homes, students, expats, and small businesses that need more room without renting a full trastero.
            </p>
            <CTAButton href="/quote" className="mt-6">
              Get storage quote
            </CTAButton>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {principles.map((principle) => {
              const Icon = principle.icon;
              return (
                <article key={principle.title} className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                  <Icon aria-hidden="true" className="h-6 w-6 text-harbor" />
                  <h2 className="mt-4 text-lg font-bold text-ink">{principle.title}</h2>
                  <p className="mt-3 text-sm leading-6 text-slate-600">{principle.description}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="rounded-lg border border-harbor/20 bg-white p-6 shadow-soft">
            <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
              <div>
                <Tags aria-hidden="true" className="h-8 w-8 text-clay" />
                <h2 className="mt-5 text-2xl font-bold tracking-normal text-ink">How the hub model works</h2>
              </div>
              <p className="text-base leading-7 text-slate-600">
                Items are received by appointment or collected, photographed, labeled, stored internally, and returned when requested. The focus is trust, organization, convenience, and a clear difference from traditional self-storage.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
