import type { Metadata } from "next";
import { Boxes, CheckCircle2, ClipboardList, Home, PackageOpen, Repeat2, Truck, Warehouse } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { SectionHeader } from "@/components/SectionHeader";
import { businessPlans, siteKeywords } from "@/data/storage";

export const metadata: Metadata = {
  title: "Business Storage",
  description:
    "Micro-warehouse support in Valencia for autónomos, small shops, technicians, online sellers, event workers, cleaning companies, and repair services.",
  keywords: siteKeywords
};

const benefits = [
  {
    title: "Store stock without renting a full warehouse",
    icon: Boxes
  },
  {
    title: "Monthly flexibility",
    icon: Repeat2
  },
  {
    title: "Organized shelves",
    icon: Warehouse
  },
  {
    title: "Item inventory",
    icon: ClipboardList
  },
  {
    title: "Pickup and return options",
    icon: Truck
  },
  {
    title: "Better than keeping stock at home",
    icon: Home
  }
];

export default function BusinessStoragePage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1fr_0.75fr] lg:items-center">
          <SectionHeader
            eyebrow="Business storage"
            title="Micro-warehouse support for small businesses"
            description="Managed storage for autónomos, small shops, technicians, online sellers, event workers, cleaning companies, and repair services that need organized space without a full warehouse lease."
          />
          <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-soft">
            <PackageOpen aria-hidden="true" className="h-8 w-8 text-clay" />
            <p className="mt-5 text-lg font-bold text-ink">Built for practical business stock</p>
            <p className="mt-3 text-sm leading-6 text-slate-600">
              Store supplies, tools, event kits, retail stock, small equipment, and online-sale inventory with a managed item record.
            </p>
            <CTAButton href="/quote" className="mt-6">
              Request business storage plan
            </CTAButton>
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="Benefits"
            title="Operational space without the warehouse overhead"
            description="The hub supports business storage needs while keeping customer access controlled and inventory organized by staff."
          />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {benefits.map((benefit) => {
              const Icon = benefit.icon;
              return (
                <article key={benefit.title} className="rounded-lg border border-slate-200 bg-mist p-5">
                  <Icon aria-hidden="true" className="h-6 w-6 text-harbor" />
                  <h2 className="mt-4 text-lg font-bold text-ink">{benefit.title}</h2>
                  <p className="mt-3 text-sm leading-6 text-slate-600">
                    Managed storage with labels, internal organization, and quote-based return options.
                  </p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="Business plans"
            title="Start small, scale as your stock changes"
            description="Plans are mock MVP examples. The exact offer is confirmed after checking volume, access, item type, and return frequency."
          />
          <div className="mt-10 grid gap-4 lg:grid-cols-3">
            {businessPlans.map((plan) => (
              <article key={plan.name} className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="text-xl font-bold text-ink">{plan.name}</h2>
                <p className="mt-3 text-2xl font-bold text-harbor">{plan.price}</p>
                <p className="mt-4 text-sm leading-6 text-slate-600">{plan.description}</p>
                <ul className="mt-5 grid gap-2 text-sm text-slate-700">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex gap-2">
                      <CheckCircle2 aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-harbor" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <div className="mt-10">
            <CTAButton href="/quote">Request business storage plan</CTAButton>
          </div>
        </div>
      </section>
    </>
  );
}
