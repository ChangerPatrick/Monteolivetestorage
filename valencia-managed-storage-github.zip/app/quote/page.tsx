import type { Metadata } from "next";
import { ClipboardCheck, LockKeyhole, Truck } from "lucide-react";
import { ManagerContactBlock } from "@/components/ManagerContactBlock";
import { ProhibitedItems } from "@/components/ProhibitedItems";
import { QuoteForm } from "@/components/QuoteForm";
import { SectionHeader } from "@/components/SectionHeader";
import { siteKeywords } from "@/data/storage";
import { adminName } from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  title: "Get Storage Quote",
  description:
    "Request a managed storage quote in Valencia for boxes, furniture, bicycles, business stock, renovation items, tools, and seasonal goods.",
  keywords: siteKeywords
};

export default function QuotePage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="Quote request"
            title="Tell us what you need to store"
            description={`Your request will be sent to ${adminName}, the storage manager. This MVP form does not use a backend yet, so it also creates WhatsApp and email links with your quote details.`}
          />
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1fr_0.55fr]">
          <QuoteForm />

          <aside className="space-y-5">
            <ManagerContactBlock compact />

            <div className="rounded-lg border border-slate-200 bg-mist p-5">
              <h2 className="text-xl font-bold text-ink">What happens next?</h2>
              <ul className="mt-5 grid gap-4 text-sm leading-6 text-slate-700">
                <li className="flex gap-3">
                  <ClipboardCheck aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-harbor" />
                  <span>We review item type, size, quantity, declared value, and storage duration.</span>
                </li>
                <li className="flex gap-3">
                  <Truck aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-harbor" />
                  <span>Pickup or delivery options are confirmed based on location and item access.</span>
                </li>
                <li className="flex gap-3">
                  <LockKeyhole aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-harbor" />
                  <span>Items are stored in a staff-managed zone, not a customer-access trastero.</span>
                </li>
              </ul>
            </div>

            <div className="rounded-lg border border-harbor/20 bg-harbor/10 p-5">
              <h2 className="text-xl font-bold text-ink">Model clarity</h2>
              <p className="mt-3 text-sm leading-6 text-slate-700">
                You are requesting managed item custody. We do not rent individual rooms, and customers do not freely access the storage zone.
              </p>
            </div>

            <ProhibitedItems />
          </aside>
        </div>
      </section>
    </>
  );
}
