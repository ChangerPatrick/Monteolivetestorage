import type { Metadata } from "next";
import { Armchair, Bike, CheckCircle2, CookingPot, Package, Paintbrush, Shirt, ToyBrick } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { SectionHeader } from "@/components/SectionHeader";
import { renovationChecklist, siteKeywords } from "@/data/storage";

export const metadata: Metadata = {
  title: "Renovation Storage",
  description:
    "Managed storage in Valencia for furniture, boxes, appliances, bicycles, and seasonal items while reforming a flat.",
  keywords: siteKeywords
};

const checklistIcons = [Armchair, Package, CookingPot, ToyBrick, Shirt, Bike];

export default function RenovationStoragePage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1fr_0.75fr] lg:items-center">
          <SectionHeader
            eyebrow="Reformas"
            title="Store your furniture and boxes during renovation"
            description="When reforming a flat in Valencia, you need clear rooms, protected belongings, and a simple way to get items back when the work is done."
          />
          <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-soft">
            <Paintbrush aria-hidden="true" className="h-8 w-8 text-clay" />
            <h2 className="mt-5 text-xl font-bold text-ink">Temporary storage for reform projects</h2>
            <p className="mt-3 text-sm leading-6 text-slate-600">
              We receive or collect your items, photograph and label them, store them internally, and return them when the renovation phase allows.
            </p>
            <CTAButton href="/quote" className="mt-6">
              Get renovation storage quote
            </CTAButton>
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="What you can store"
            title="Keep the flat clear while work is underway"
            description="Good for partial reforms, full flat renovations, painting, flooring, kitchen work, and temporary relocation of bulky items."
          />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {renovationChecklist.map((item, index) => {
              const Icon = checklistIcons[index] ?? CheckCircle2;
              return (
                <article key={item} className="rounded-lg border border-slate-200 bg-mist p-5">
                  <Icon aria-hidden="true" className="h-6 w-6 text-harbor" />
                  <h2 className="mt-4 text-lg font-bold text-ink">{item}</h2>
                  <p className="mt-3 text-sm leading-6 text-slate-600">
                    Item custody with photo record, internal label, and return request options.
                  </p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl rounded-lg border border-harbor/20 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-sm font-bold uppercase tracking-wide text-clay">Managed, not self-access</p>
              <h2 className="mt-3 text-2xl font-bold tracking-normal text-ink">
                Your items stay organized while the builders work
              </h2>
              <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-600">
                This service is a managed guardamuebles-style option, not a private trastero. Staff manage the storage zone and item returns.
              </p>
            </div>
            <CTAButton href="/quote" className="shrink-0">
              Get renovation storage quote
            </CTAButton>
          </div>
        </div>
      </section>
    </>
  );
}
