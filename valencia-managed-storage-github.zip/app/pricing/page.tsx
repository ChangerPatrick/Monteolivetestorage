import type { Metadata } from "next";
import { ClipboardList, Info } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { PricingCard } from "@/components/PricingCard";
import { SectionHeader } from "@/components/SectionHeader";
import { pricingPlans, siteKeywords } from "@/data/storage";
import { businessName } from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Item-based managed storage pricing in Valencia for boxes, suitcases, bicycles, small furniture, business shelves, pickup, and return delivery.",
  keywords: siteKeywords
};

export default function PricingPage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-8 lg:grid-cols-[1fr_0.75fr] lg:items-end">
            <SectionHeader
              eyebrow="Pricing"
              title="Clear item-based pricing, confirmed by quote"
              description={`Pay for storing specific items instead of renting an empty room. Prices below are MVP guide prices for ${businessName}.`}
            />
            <div className="rounded-lg border border-harbor/20 bg-white p-5 shadow-sm">
              <div className="flex gap-3">
                <Info aria-hidden="true" className="mt-1 h-5 w-5 shrink-0 text-harbor" />
                <p className="text-sm leading-6 text-slate-700">
                  Final price depends on item size, access needs, storage duration, declared value, and pickup/return requirements.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {pricingPlans.map((plan) => (
              <PricingCard key={plan.name} plan={plan} />
            ))}
          </div>

          <div className="mt-10 rounded-lg border border-slate-200 bg-mist p-6">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-white text-clay">
                  <ClipboardList aria-hidden="true" className="h-5 w-5" />
                </span>
                <div>
                  <h2 className="text-xl font-bold text-ink">Request an exact quote</h2>
                  <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
                    We will check your item list, pickup location, access, and expected duration before confirming the exact price.
                  </p>
                </div>
              </div>
              <CTAButton href="/quote" className="shrink-0">
                Request exact quote
              </CTAButton>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
