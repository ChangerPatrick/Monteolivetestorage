import type { Metadata } from "next";
import { HelpCircle } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { FAQAccordion } from "@/components/FAQAccordion";
import { ProhibitedItems } from "@/components/ProhibitedItems";
import { SectionHeader } from "@/components/SectionHeader";
import { faqs, siteKeywords } from "@/data/storage";

export const metadata: Metadata = {
  title: "FAQ",
  description:
    "Frequently asked questions about managed storage in Valencia, including access, pickup, prohibited items, insurance options, and pricing.",
  keywords: siteKeywords
};

export default function FAQPage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="FAQ"
            title="Questions about managed storage"
            description="Clear answers about how this differs from a normal trastero, how item returns work, and what is not allowed."
          />
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1fr_0.45fr]">
          <FAQAccordion faqs={faqs} />

          <aside className="space-y-5">
            <div className="rounded-lg border border-slate-200 bg-mist p-5">
              <HelpCircle aria-hidden="true" className="h-7 w-7 text-clay" />
              <h2 className="mt-4 text-xl font-bold text-ink">Still unsure?</h2>
              <p className="mt-3 text-sm leading-6 text-slate-600">
                Send your item list and timing. We can explain whether managed storage is a good fit for your case.
              </p>
              <CTAButton href="/quote" className="mt-6">
                Get storage quote
              </CTAButton>
            </div>

            <div className="rounded-lg border border-harbor/20 bg-harbor/10 p-5">
              <h2 className="text-xl font-bold text-ink">Important distinction</h2>
              <p className="mt-3 text-sm leading-6 text-slate-700">
                This is not a room rental service. Customers do not enter the storage zone; items are managed by staff.
              </p>
            </div>
          </aside>
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <ProhibitedItems />
        </div>
      </section>
    </>
  );
}
