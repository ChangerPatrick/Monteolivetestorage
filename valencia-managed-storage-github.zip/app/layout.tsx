import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { siteKeywords } from "@/data/storage";
import { businessName } from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  metadataBase: new URL("https://valenciamanagedstorage.com"),
  title: {
    default: `${businessName} | Managed Item Storage in Valencia`,
    template: `%s | ${businessName}`
  },
  description:
    "Managed storage in Valencia for homes and small businesses. We collect, photograph, label, store, and return your items without renting a full trastero.",
  keywords: siteKeywords,
  openGraph: {
    title: businessName,
    description:
      "Storage without renting a room. Managed item custody, photo inventory, pickup, storage, and return in Valencia.",
    url: "https://valenciamanagedstorage.com",
    siteName: businessName,
    locale: "en_ES",
    type: "website"
  }
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-white focus:px-4 focus:py-3 focus:text-sm focus:font-bold focus:text-harbor focus:shadow-soft"
        >
          Skip to content
        </a>
        <Header />
        <main id="main-content">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
