import type { Metadata } from "next";
import { Eye, LockKeyhole } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { MyItemsDemo } from "@/components/MyItemsDemo";
import { SectionHeader } from "@/components/SectionHeader";
import { siteKeywords } from "@/data/storage";
import { businessName } from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  title: "My Items Demo",
  description: `Mock customer-facing item inventory demo for ${businessName} showing stored items, photo placeholders, monthly costs, and return requests.`,
  keywords: siteKeywords
};

export default function MyItemsDemoPage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1fr_0.75fr] lg:items-end">
          <SectionHeader
            eyebrow="Customer demo"
            title="My Items future customer view"
            description="A mock preview of how a future customer could see stored items, photo records, monthly costs, and request a return. This page has no login and no real account data."
          />
          <div className="rounded-lg border border-harbor/20 bg-white p-5 shadow-sm">
            <div className="flex gap-3">
              <Eye aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-harbor" />
              <p className="text-sm leading-6 text-slate-700">
                Demo customer: Sofia Navarro. Return requests update local page state and log to the console only.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <MyItemsDemo />
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl rounded-lg border border-clay/25 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex gap-4">
              <LockKeyhole aria-hidden="true" className="mt-1 h-7 w-7 shrink-0 text-clay" />
              <div>
                <h2 className="text-2xl font-bold tracking-normal text-ink">Admin dashboard demo</h2>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
                  The internal demo shows how staff could filter quote requests and manage item inventory.
                </p>
              </div>
            </div>
            <CTAButton href="/admin-demo" variant="outline" className="shrink-0">
              View admin demo
            </CTAButton>
          </div>
        </div>
      </section>
    </>
  );
}
