import type { Metadata } from "next";
import { ShieldCheck } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { Hero } from "@/components/Hero";
import { HowItWorksStep } from "@/components/HowItWorksStep";
import { PricingCard } from "@/components/PricingCard";
import { SectionHeader } from "@/components/SectionHeader";
import { TrustBadges } from "@/components/TrustBadges";
import { UseCaseCard } from "@/components/UseCaseCard";
import { howItWorks, pricingPlans, siteKeywords, useCases } from "@/data/storage";
import { businessName } from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  title: "Managed Storage for Homes and Small Businesses in Valencia",
  description: `${businessName} collects, photographs, labels, stores, and returns your items. A local alternative to renting a full trastero.`,
  keywords: siteKeywords
};

export default function HomePage() {
  return (
    <>
      <Hero />

      <section className="bg-white px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <TrustBadges />
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <SectionHeader
              eyebrow="Not a normal trastero"
              title="You store items, not a private room"
              description={
                <p>
                  Customers do not enter the storage area or rent individual trasteros. Our staff receive, photograph, label, organize, and return specific items when requested.
                </p>
              }
            />
            <div className="grid gap-4 sm:grid-cols-3">
              {[
                "Managed custody",
                "Internal inventory",
                "Staff-only storage zone"
              ].map((item) => (
                <div key={item} className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                  <ShieldCheck aria-hidden="true" className="h-6 w-6 text-harbor" />
                  <p className="mt-4 text-base font-bold text-ink">{item}</p>
                  <p className="mt-2 text-sm leading-6 text-slate-600">
                    Almacenaje gestionado para objetos concretos en Valencia.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="How it works"
            title="Simple storage from request to return"
            description="A clear process for homes, students, expats, autónomos, and small businesses that need organized space without managing a room."
          />
          <ol className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            {howItWorks.map((step, index) => (
              <HowItWorksStep
                key={step.title}
                step={index + 1}
                title={step.title}
                description={step.description}
              />
            ))}
          </ol>
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="Use cases"
            title="Flexible storage for daily Valencia life"
            description="From flat renovations to small business stock, the service is built around the real item list you need stored."
          />
          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {useCases.map((useCase) => (
              <UseCaseCard key={useCase.title} useCase={useCase} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
            <SectionHeader
              eyebrow="Pricing preview"
              title="Start with item-based monthly pricing"
              description="Exact quotes depend on item size, access, duration, declared value, and pickup or return needs."
            />
            <CTAButton href="/pricing" variant="outline" className="shrink-0">
              See all pricing
            </CTAButton>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {pricingPlans.slice(0, 6).map((plan) => (
              <PricingCard key={plan.name} plan={plan} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-harbor px-4 py-16 text-white sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-3xl">
            <p className="text-sm font-bold uppercase tracking-wide text-white/75">Ready to check space?</p>
            <h2 className="mt-3 text-3xl font-bold tracking-normal sm:text-4xl">
              Get a quote for your item list
            </h2>
            <p className="mt-4 text-base leading-7 text-white/85">
              Send the items, neighborhood, pickup preference, and expected duration. We will reply by WhatsApp or email with a practical storage quote.
            </p>
          </div>
          <CTAButton href="/quote" variant="secondary" className="bg-white text-harbor hover:bg-mist">
            Get storage quote
          </CTAButton>
        </div>
      </section>
    </>
  );
}
