import type { Metadata } from "next";
import { CTAButton } from "@/components/CTAButton";
import { ContactForm } from "@/components/ContactForm";
import { ManagerContactBlock } from "@/components/ManagerContactBlock";
import { SectionHeader } from "@/components/SectionHeader";
import { ServiceAreaList } from "@/components/ServiceAreaList";
import { siteKeywords } from "@/data/storage";
import { adminName, businessName } from "@/src/lib/siteConfig";

export const metadata: Metadata = {
  title: "Contact",
  description: `Contact ${businessName} for managed item storage, pickup, and return options in Monteolivete and nearby Valencia neighborhoods.`,
  keywords: siteKeywords
};

export default function ContactPage() {
  return (
    <>
      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="Contact"
            title="Talk to us about your storage needs"
            description="Send a question, request a quote, or ask about pickup and return options in Valencia."
          />
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.65fr_1fr]">
          <aside className="space-y-5">
            <ManagerContactBlock compact />

            <div className="rounded-lg border border-harbor/20 bg-harbor/10 p-5">
              <h2 className="text-xl font-bold text-ink">Service model</h2>
              <p className="mt-3 text-sm leading-6 text-slate-700">
                Customers do not rent individual rooms or access the storage zone. We manage specific items with labels, records, storage, and return requests.
              </p>
              <p className="mt-3 text-sm leading-6 text-slate-700">
                Storage requests are handled by {adminName}, the storage manager.
              </p>
              <CTAButton href="/quote" className="mt-5 w-full">
                Get storage quote
              </CTAButton>
            </div>
          </aside>

          <ContactForm />
        </div>
      </section>

      <section className="bg-mist px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="Service area"
            title="Initial Valencia neighborhoods"
            description="Pickup and return availability depends on item type, access, timing, and address."
          />
          <div className="mt-10">
            <ServiceAreaList />
          </div>
        </div>
      </section>
    </>
  );
}
