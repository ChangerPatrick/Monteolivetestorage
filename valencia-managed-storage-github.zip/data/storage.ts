import { serviceArea } from "@/src/lib/siteConfig";

export type PricingPlan = {
  name: string;
  price: string;
  unit: string;
  description: string;
  highlights: string[];
  tag?: string;
};

export type FAQ = {
  question: string;
  answer: string;
};

export type UseCase = {
  title: string;
  spanishLabel: string;
  description: string;
  icon: "paintbrush" | "home" | "graduation" | "bike" | "briefcase" | "package";
};

export type BusinessPlan = {
  name: string;
  price: string;
  description: string;
  features: string[];
};

export type MockBookingRequest = {
  name: string;
  neighborhood: string;
  purpose: string;
  items: string[];
  quantity: string;
  pickup: "Yes" | "No" | "Not sure";
  duration: string;
};

export type ItemStatus =
  | "Received"
  | "Photographed"
  | "Labeled"
  | "Stored"
  | "Return requested"
  | "Returned";

export type WarehouseLocation =
  | "Shelf A1"
  | "Shelf A2"
  | "Rack B1"
  | "Bike Zone"
  | "Furniture Zone";

export type MockQuoteRequest = {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  neighborhood: string;
  purpose: string;
  itemTypes: string[];
  quantity: string;
  pickup: "Yes" | "No" | "Not sure";
  requestedStartDate: string;
  expectedDuration: string;
  submittedAt: string;
  note: string;
};

export type StoredInventoryItem = {
  id: string;
  customerName: string;
  itemName: string;
  itemType: string;
  status: ItemStatus;
  storageStartDate: string;
  monthlyPrice: number;
  location: WarehouseLocation;
  photoLabel: string;
  photoTone: "harbor" | "clay" | "citrus" | "olive" | "slate";
  returnWindow?: string;
};

export const siteKeywords = [
  "managed storage Valencia",
  "guardamuebles Valencia",
  "trastero alternative Valencia",
  "storage for renovation Valencia",
  "business storage Valencia",
  "almacenaje Valencia",
  "guardamuebles Monteolivete"
];

export const trustBadges = [
  {
    label: "Item inventory",
    spanishLabel: "Inventario de objetos"
  },
  {
    label: "Photo record",
    spanishLabel: "Registro con fotos"
  },
  {
    label: "Flexible monthly storage",
    spanishLabel: "Almacenaje mensual flexible"
  },
  {
    label: "Pickup and return available",
    spanishLabel: "Recogida y devolución"
  },
  {
    label: "No customer access to storage zone",
    spanishLabel: "Zona gestionada solo por personal"
  }
];

export const howItWorks = [
  {
    title: "Tell us what you need to store",
    description: "Send a simple list of boxes, bikes, furniture, tools, stock, or seasonal items."
  },
  {
    title: "We collect or receive your items",
    description: "Pickup can be arranged in Valencia, or items can be received by appointment."
  },
  {
    title: "We photograph and label everything",
    description: "Each item gets a clear internal label and photo record for managed inventory."
  },
  {
    title: "We store items safely",
    description: "Your items are kept in a managed storage zone, organized by staff only."
  },
  {
    title: "Request return when needed",
    description: "Ask for one item or everything back, with return delivery options when available."
  }
];

export const useCases: UseCase[] = [
  {
    title: "Renovation storage",
    spanishLabel: "Almacenaje durante reformas",
    description: "Clear furniture and boxes out of the flat while work is happening.",
    icon: "paintbrush"
  },
  {
    title: "Moving home",
    spanishLabel: "Mudanzas",
    description: "Bridge the gap between moving dates without renting a full room.",
    icon: "home"
  },
  {
    title: "Students and expats",
    spanishLabel: "Estudiantes y expatriados",
    description: "Store luggage, boxes, bikes, and seasonal goods between stays.",
    icon: "graduation"
  },
  {
    title: "Bicycles and seasonal items",
    spanishLabel: "Bicis y temporada",
    description: "Keep bulky items out of the hallway, balcony, or spare room.",
    icon: "bike"
  },
  {
    title: "Autónomos and small businesses",
    spanishLabel: "Autónomos y pequeños negocios",
    description: "Managed space for stock, equipment, tools, supplies, and event materials.",
    icon: "briefcase"
  },
  {
    title: "E-commerce stock",
    spanishLabel: "Stock para venta online",
    description: "Organized shelves for online sellers who need flexible storage.",
    icon: "package"
  }
];

export const pricingPlans: PricingPlan[] = [
  {
    name: "Standard box",
    price: "from €4",
    unit: "/ month",
    description: "For books, clothing, household items, and archived goods.",
    highlights: ["Photo record", "Item label", "Monthly flexibility"],
    tag: "Most common"
  },
  {
    name: "Large box",
    price: "from €7",
    unit: "/ month",
    description: "For bulkier home items, seasonal goods, or larger stock units.",
    highlights: ["Larger volume", "Inventory record", "Return on request"]
  },
  {
    name: "Suitcase",
    price: "from €8",
    unit: "/ month",
    description: "Useful for students, expats, travel gaps, and temporary stays.",
    highlights: ["Ideal for luggage", "Pickup option", "Short-term friendly"]
  },
  {
    name: "Bicycle",
    price: "from €15",
    unit: "/ month",
    description: "Managed bike storage without taking space in a flat or stairwell.",
    highlights: ["Photo record", "Staff-managed zone", "Seasonal storage"]
  },
  {
    name: "Small furniture item",
    price: "from €12",
    unit: "/ month",
    description: "For chairs, small tables, bedside units, and compact furniture.",
    highlights: ["By-item pricing", "Renovation friendly", "Custom quote for sets"]
  },
  {
    name: "Business shelf",
    price: "from €59",
    unit: "/ month",
    description: "A managed shelf plan for stock, tools, supplies, or event materials.",
    highlights: ["Organized shelves", "Item inventory", "Flexible monthly plan"],
    tag: "For autónomos"
  },
  {
    name: "Custom business storage",
    price: "Quote required",
    unit: "",
    description: "For larger stock volumes, repeated pickup needs, or special handling.",
    highlights: ["Tailored volume", "Business workflows", "Return coordination"]
  },
  {
    name: "Pickup from home",
    price: "from €25",
    unit: "",
    description: "Collection in Valencia depending on neighborhood, access, and item type.",
    highlights: ["Home pickup", "By appointment", "Quote confirmed first"]
  },
  {
    name: "Return delivery",
    price: "from €25",
    unit: "",
    description: "Return one item, a group of items, or the full storage order.",
    highlights: ["Flexible return", "Local delivery", "Staff managed"]
  }
];

export const businessPlans: BusinessPlan[] = [
  {
    name: "Starter shelf",
    price: "from €59 / month",
    description: "For a compact set of stock, tools, event materials, or supplies.",
    features: ["Managed shelf space", "Photo inventory", "Monthly flexibility"]
  },
  {
    name: "Growth shelf",
    price: "custom quote",
    description: "For growing online sellers, technicians, and small shops with changing stock.",
    features: ["More volume", "Return requests", "Pickup and delivery options"]
  },
  {
    name: "Custom storage",
    price: "quote required",
    description: "For irregular stock, bulky equipment, repeated access needs, or special handling.",
    features: ["Tailored handling", "Operational review", "Business support"]
  }
];

export const renovationChecklist = [
  "Furniture",
  "Boxes",
  "Appliances",
  "Children's items",
  "Seasonal goods",
  "Bicycles"
];

export const faqs: FAQ[] = [
  {
    question: "Is this a normal trastero?",
    answer:
      "No. This is managed storage. You pay to store specific items, not to rent a private room."
  },
  {
    question: "Can I enter the storage area?",
    answer:
      "No. For security and organization, only staff manage the storage zone."
  },
  {
    question: "Can I request one item back?",
    answer:
      "Yes. Items are labeled and can be requested for return."
  },
  {
    question: "Do you collect items?",
    answer:
      "Pickup can be arranged depending on location and item type."
  },
  {
    question: "What items are not allowed?",
    answer:
      "Food, liquids, flammable goods, chemicals, illegal goods, cash, jewelry, animals, plants, and dangerous items are not allowed."
  },
  {
    question: "Is insurance included?",
    answer:
      "Basic handling rules apply, and optional declared-value coverage can be offered later. Insurance options coming soon."
  },
  {
    question: "How much does it cost?",
    answer:
      "It depends on item type, volume, duration, pickup, return, and declared value."
  },
  {
    question: "Where are you located?",
    answer:
      "Valencia, with initial focus on Monteolivete and nearby neighborhoods."
  }
];

export const neighborhoods = [...serviceArea];

export const prohibitedItems = [
  "Food",
  "Perishables",
  "Liquids",
  "Chemicals",
  "Gas bottles",
  "Flammable items",
  "Batteries unless approved",
  "Illegal goods",
  "Cash",
  "Jewelry",
  "Weapons",
  "Animals",
  "Plants",
  "High-value art",
  "Confidential legal documents unless separately agreed"
];

export const storagePurposes = [
  "Moving",
  "Renovation",
  "Student/expat",
  "Business stock",
  "Bicycle",
  "Seasonal storage",
  "Other"
];

export const itemTypes = [
  "Boxes",
  "Suitcases",
  "Furniture",
  "Bicycle",
  "Tools",
  "Business stock",
  "Documents",
  "Other"
];

export const expectedDurations = [
  "Less than 1 month",
  "1-3 months",
  "3-6 months",
  "6+ months"
];

export const itemStatuses: ItemStatus[] = [
  "Received",
  "Photographed",
  "Labeled",
  "Stored",
  "Return requested",
  "Returned"
];

export const warehouseLocations: WarehouseLocation[] = [
  "Shelf A1",
  "Shelf A2",
  "Rack B1",
  "Bike Zone",
  "Furniture Zone"
];

export const mockBookingRequests: MockBookingRequest[] = [
  {
    name: "Renovation flat example",
    neighborhood: "Monteolivete",
    purpose: "Renovation",
    items: ["Furniture", "Boxes", "Bicycle"],
    quantity: "12 boxes, 4 chairs, 1 bicycle",
    pickup: "Yes",
    duration: "1-3 months"
  },
  {
    name: "Small business shelf example",
    neighborhood: "Ruzafa",
    purpose: "Business stock",
    items: ["Business stock", "Tools"],
    quantity: "20 stock boxes and 2 tool cases",
    pickup: "Not sure",
    duration: "3-6 months"
  }
];

export const mockQuoteRequests: MockQuoteRequest[] = [
  {
    id: "QR-1042",
    customerName: "Sofia Navarro",
    email: "sofia@example.com",
    phone: "+34 600 123 450",
    neighborhood: "Monteolivete",
    purpose: "Renovation",
    itemTypes: ["Boxes", "Furniture", "Bicycle"],
    quantity: "10 boxes, 2 chairs, 1 bicycle",
    pickup: "Yes",
    requestedStartDate: "2026-06-03",
    expectedDuration: "1-3 months",
    submittedAt: "2026-05-21",
    note: "Lift access. Needs pickup before floor work starts."
  },
  {
    id: "QR-1043",
    customerName: "Mateo Ruiz Studio",
    email: "mateo@example.com",
    phone: "+34 611 222 333",
    neighborhood: "Ruzafa",
    purpose: "Business stock",
    itemTypes: ["Business stock", "Tools"],
    quantity: "18 stock boxes and 3 tool cases",
    pickup: "Not sure",
    requestedStartDate: "2026-06-10",
    expectedDuration: "3-6 months",
    submittedAt: "2026-05-22",
    note: "Online seller wants starter shelf pricing."
  },
  {
    id: "QR-1044",
    customerName: "Elena Martín",
    email: "elena@example.com",
    phone: "+34 622 444 555",
    neighborhood: "Malilla",
    purpose: "Student/expat",
    itemTypes: ["Suitcases", "Boxes"],
    quantity: "2 suitcases and 4 boxes",
    pickup: "No",
    requestedStartDate: "2026-06-28",
    expectedDuration: "Less than 1 month",
    submittedAt: "2026-05-22",
    note: "Summer gap storage before new apartment contract."
  }
];

export const storedInventoryItems: StoredInventoryItem[] = [
  {
    id: "ITM-2001",
    customerName: "Sofia Navarro",
    itemName: "Kitchen renovation boxes",
    itemType: "Boxes",
    status: "Stored",
    storageStartDate: "2026-04-18",
    monthlyPrice: 28,
    location: "Shelf A1",
    photoLabel: "Box set photo",
    photoTone: "harbor"
  },
  {
    id: "ITM-2002",
    customerName: "Sofia Navarro",
    itemName: "City bicycle",
    itemType: "Bicycle",
    status: "Return requested",
    storageStartDate: "2026-04-18",
    monthlyPrice: 15,
    location: "Bike Zone",
    photoLabel: "Bicycle photo",
    photoTone: "olive",
    returnWindow: "Requested for 2026-05-27"
  },
  {
    id: "ITM-2003",
    customerName: "Mateo Ruiz Studio",
    itemName: "Printed stock cartons",
    itemType: "Business stock",
    status: "Labeled",
    storageStartDate: "2026-05-06",
    monthlyPrice: 59,
    location: "Shelf A2",
    photoLabel: "Stock carton photo",
    photoTone: "citrus"
  },
  {
    id: "ITM-2004",
    customerName: "Elena Martín",
    itemName: "Blue suitcase",
    itemType: "Suitcases",
    status: "Photographed",
    storageStartDate: "2026-05-15",
    monthlyPrice: 8,
    location: "Shelf A1",
    photoLabel: "Suitcase photo",
    photoTone: "slate"
  },
  {
    id: "ITM-2005",
    customerName: "Carlos Ibáñez",
    itemName: "Dining chairs",
    itemType: "Furniture",
    status: "Received",
    storageStartDate: "2026-05-20",
    monthlyPrice: 24,
    location: "Furniture Zone",
    photoLabel: "Furniture photo pending",
    photoTone: "clay"
  },
  {
    id: "ITM-2006",
    customerName: "Sofia Navarro",
    itemName: "Children's seasonal box",
    itemType: "Boxes",
    status: "Returned",
    storageStartDate: "2026-02-01",
    monthlyPrice: 4,
    location: "Rack B1",
    photoLabel: "Returned box photo",
    photoTone: "slate",
    returnWindow: "Returned on 2026-05-12"
  }
];

export const legalDisclaimer =
  "This website is an MVP concept. Actual operation requires professional review of licensing, fire safety, insurance, contracts, and local activity compatibility.";
