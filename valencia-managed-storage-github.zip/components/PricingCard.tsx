import { CheckCircle2 } from "lucide-react";
import type { PricingPlan } from "@/data/storage";

type PricingCardProps = {
  plan: PricingPlan;
};

export function PricingCard({ plan }: PricingCardProps) {
  return (
    <article className="flex h-full flex-col rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <h3 className="text-lg font-bold text-ink">{plan.name}</h3>
        {plan.tag ? (
          <span className="rounded-full bg-citrus/25 px-3 py-1 text-xs font-bold text-ink">
            {plan.tag}
          </span>
        ) : null}
      </div>
      <p className="mt-4">
        <span className="text-3xl font-bold text-ink">{plan.price}</span>
        {plan.unit ? <span className="ml-1 text-sm font-semibold text-slate-500">{plan.unit}</span> : null}
      </p>
      <p className="mt-3 text-sm leading-6 text-slate-600">{plan.description}</p>
      <ul className="mt-5 grid gap-2 text-sm text-slate-700">
        {plan.highlights.map((highlight) => (
          <li key={highlight} className="flex gap-2">
            <CheckCircle2 aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-harbor" />
            <span>{highlight}</span>
          </li>
        ))}
      </ul>
    </article>
  );
}
