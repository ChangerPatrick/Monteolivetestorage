type HowItWorksStepProps = {
  step: number;
  title: string;
  description: string;
};

export function HowItWorksStep({ step, title, description }: HowItWorksStepProps) {
  return (
    <li className="relative rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-citrus text-sm font-bold text-ink">
        {step}
      </span>
      <h3 className="mt-5 text-lg font-bold text-ink">{title}</h3>
      <p className="mt-3 text-sm leading-6 text-slate-600">{description}</p>
    </li>
  );
}
