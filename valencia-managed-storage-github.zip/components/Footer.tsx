import Link from "next/link";
import { Mail, MapPin, MessageCircle, ShieldCheck } from "lucide-react";
import { legalDisclaimer } from "@/data/storage";
import {
  adminEmail,
  adminName,
  adminPhoneDisplay,
  businessName
} from "@/src/lib/siteConfig";
import { createGeneralWhatsappHref } from "@/src/lib/quoteLinks";

const footerLinks = [
  { href: "/pricing", label: "Pricing" },
  { href: "/business-storage", label: "Business Storage" },
  { href: "/renovation-storage", label: "Renovation Storage" },
  { href: "/about", label: "About" },
  { href: "/faq", label: "FAQ" },
  { href: "/contact", label: "Contact" },
  { href: "/quote", label: "Get Quote" },
  { href: "/admin-demo", label: "Admin Demo" },
  { href: "/my-items-demo", label: "My Items Demo" }
];

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[1.3fr_1fr_1fr] lg:px-8">
        <div>
          <p className="text-lg font-bold text-ink">{businessName}</p>
          <p className="mt-1 text-sm font-semibold text-harbor">Monteolivete Storage Hub</p>
          <p className="mt-4 max-w-md text-sm leading-6 text-slate-600">
            Storage without renting a room. We collect, label, store, and return your items from a staff-managed storage hub in Valencia.
          </p>
        </div>

        <div>
          <p className="text-sm font-bold uppercase tracking-wide text-ink">Navigation</p>
          <ul className="mt-4 grid gap-2 text-sm text-slate-600">
            {footerLinks.map((link) => (
              <li key={link.href}>
                <Link className="hover:text-harbor" href={link.href}>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-sm font-bold uppercase tracking-wide text-ink">Local service</p>
          <ul className="mt-4 grid gap-3 text-sm text-slate-600">
            <li className="flex gap-2">
              <MapPin aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
              <span>Monteolivete and nearby Valencia neighborhoods.</span>
            </li>
            <li className="flex gap-2">
              <Mail aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
              <a className="hover:text-harbor" href={`mailto:${adminEmail}`}>
                {adminEmail}
              </a>
            </li>
            <li className="flex gap-2">
              <MessageCircle aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
              <a className="hover:text-harbor" href={createGeneralWhatsappHref()} target="_blank" rel="noreferrer">
                {adminPhoneDisplay}
              </a>
            </li>
            <li className="flex gap-2">
              <ShieldCheck aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
              <span>No customer access to the storage zone.</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-slate-200 bg-mist">
        <div className="mx-auto max-w-7xl px-4 py-5 text-xs leading-5 text-slate-600 sm:px-6 lg:px-8">
          <p className="mb-2">
            Managed storage requests are handled by {adminName}. Email: {adminEmail}. WhatsApp:{" "}
            {adminPhoneDisplay}
          </p>
          <p>{legalDisclaimer}</p>
        </div>
      </div>
    </footer>
  );
}
