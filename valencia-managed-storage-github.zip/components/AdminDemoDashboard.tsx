"use client";

import { Search, SlidersHorizontal } from "lucide-react";
import { useMemo, useState } from "react";
import { StatusBadge } from "@/components/StatusBadge";
import {
  itemStatuses,
  itemTypes,
  mockQuoteRequests,
  storedInventoryItems,
  type ItemStatus
} from "@/data/storage";

const formatCurrency = (value: number) =>
  new Intl.NumberFormat("en-IE", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0
  }).format(value);

export function AdminDemoDashboard() {
  const [customerSearch, setCustomerSearch] = useState("");
  const [itemType, setItemType] = useState("All");
  const [status, setStatus] = useState<ItemStatus | "All">("All");

  const normalizedCustomer = customerSearch.trim().toLowerCase();

  const filteredQuotes = useMemo(() => {
    return mockQuoteRequests.filter((request) => {
      const matchesCustomer =
        !normalizedCustomer || request.customerName.toLowerCase().includes(normalizedCustomer);
      const matchesItemType = itemType === "All" || request.itemTypes.includes(itemType);

      return matchesCustomer && matchesItemType;
    });
  }, [itemType, normalizedCustomer]);

  const filteredInventory = useMemo(() => {
    return storedInventoryItems.filter((item) => {
      const matchesCustomer =
        !normalizedCustomer || item.customerName.toLowerCase().includes(normalizedCustomer);
      const matchesItemType = itemType === "All" || item.itemType === itemType;
      const matchesStatus = status === "All" || item.status === status;

      return matchesCustomer && matchesItemType && matchesStatus;
    });
  }, [itemType, normalizedCustomer, status]);

  const totalMonthlyValue = filteredInventory.reduce((total, item) => total + item.monthlyPrice, 0);

  return (
    <div className="space-y-8">
      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-harbor/10 text-harbor">
            <SlidersHorizontal aria-hidden="true" className="h-5 w-5" />
          </span>
          <div>
            <h2 className="text-xl font-bold text-ink">Demo filters</h2>
            <p className="mt-1 text-sm leading-6 text-slate-600">
              Search mock records by customer, item type, and inventory status.
            </p>
          </div>
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-[1.2fr_0.8fr_0.8fr]">
          <label className="text-sm font-bold text-ink">
            Customer name
            <span className="relative mt-2 block">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              />
              <input
                value={customerSearch}
                onChange={(event) => setCustomerSearch(event.target.value)}
                className="min-h-11 w-full rounded-lg border border-slate-300 bg-white py-2 pl-10 pr-3 text-base text-ink outline-none transition placeholder:text-slate-400 focus:border-harbor focus:ring-2 focus:ring-harbor/20"
                placeholder="Sofia, Mateo, Elena..."
                type="search"
              />
            </span>
          </label>

          <label className="text-sm font-bold text-ink">
            Item type
            <select
              value={itemType}
              onChange={(event) => setItemType(event.target.value)}
              className="mt-2 min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-base text-ink outline-none transition focus:border-harbor focus:ring-2 focus:ring-harbor/20"
            >
              <option value="All">All item types</option>
              {itemTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </label>

          <label className="text-sm font-bold text-ink">
            Status
            <select
              value={status}
              onChange={(event) => setStatus(event.target.value as ItemStatus | "All")}
              className="mt-2 min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-base text-ink outline-none transition focus:border-harbor focus:ring-2 focus:ring-harbor/20"
            >
              <option value="All">All statuses</option>
              {itemStatuses.map((itemStatus) => (
                <option key={itemStatus} value={itemStatus}>
                  {itemStatus}
                </option>
              ))}
            </select>
          </label>
        </div>
      </section>

      <section>
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm font-semibold text-slate-500">New quote requests</p>
            <p className="mt-2 text-3xl font-bold text-ink">{filteredQuotes.length}</p>
          </div>
          <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm font-semibold text-slate-500">Visible inventory items</p>
            <p className="mt-2 text-3xl font-bold text-ink">{filteredInventory.length}</p>
          </div>
          <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm font-semibold text-slate-500">Monthly value shown</p>
            <p className="mt-2 text-3xl font-bold text-ink">{formatCurrency(totalMonthlyValue)}</p>
          </div>
        </div>
      </section>

      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-bold uppercase tracking-wide text-clay">Requests</p>
            <h2 className="mt-2 text-2xl font-bold tracking-normal text-ink">New quote requests</h2>
          </div>
          <p className="text-sm font-semibold text-slate-500">{filteredQuotes.length} shown</p>
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          {filteredQuotes.map((request) => (
            <article key={request.id} className="rounded-lg border border-slate-200 bg-mist p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-bold text-ink">{request.customerName}</h3>
                  <p className="mt-1 text-xs font-semibold text-harbor">{request.id}</p>
                </div>
                <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-ink">
                  {request.submittedAt}
                </span>
              </div>
              <dl className="mt-4 grid gap-3 text-sm">
                <div>
                  <dt className="font-semibold text-slate-500">Items</dt>
                  <dd className="mt-1 text-ink">{request.itemTypes.join(", ")}</dd>
                </div>
                <div>
                  <dt className="font-semibold text-slate-500">Quantity</dt>
                  <dd className="mt-1 text-ink">{request.quantity}</dd>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <dt className="font-semibold text-slate-500">Start</dt>
                    <dd className="mt-1 text-ink">{request.requestedStartDate}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold text-slate-500">Pickup</dt>
                    <dd className="mt-1 text-ink">{request.pickup}</dd>
                  </div>
                </div>
              </dl>
              <p className="mt-4 rounded-md bg-white p-3 text-sm leading-6 text-slate-600">{request.note}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-bold uppercase tracking-wide text-clay">Inventory</p>
            <h2 className="mt-2 text-2xl font-bold tracking-normal text-ink">Stored items</h2>
          </div>
          <p className="text-sm font-semibold text-slate-500">{filteredInventory.length} shown</p>
        </div>

        <div className="mt-6 overflow-hidden rounded-lg border border-slate-200">
          <div className="hidden bg-mist px-4 py-3 text-xs font-bold uppercase tracking-wide text-slate-500 lg:grid lg:grid-cols-[1fr_0.8fr_0.8fr_0.8fr_0.7fr_0.8fr]">
            <span>Customer</span>
            <span>Item type</span>
            <span>Status</span>
            <span>Start date</span>
            <span>Price</span>
            <span>Location</span>
          </div>

          <div className="divide-y divide-slate-200">
            {filteredInventory.map((item) => (
              <article
                key={item.id}
                className="grid gap-3 bg-white px-4 py-4 text-sm lg:grid-cols-[1fr_0.8fr_0.8fr_0.8fr_0.7fr_0.8fr] lg:items-center"
              >
                <div>
                  <p className="font-bold text-ink">{item.customerName}</p>
                  <p className="mt-1 text-xs font-semibold text-slate-500">{item.itemName}</p>
                </div>
                <div>
                  <span className="lg:hidden text-xs font-bold uppercase tracking-wide text-slate-500">Item type</span>
                  <p className="mt-1 lg:mt-0 text-ink">{item.itemType}</p>
                </div>
                <div>
                  <StatusBadge status={item.status} />
                </div>
                <div>
                  <span className="lg:hidden text-xs font-bold uppercase tracking-wide text-slate-500">Start date</span>
                  <p className="mt-1 lg:mt-0 text-ink">{item.storageStartDate}</p>
                </div>
                <div>
                  <span className="lg:hidden text-xs font-bold uppercase tracking-wide text-slate-500">Monthly price</span>
                  <p className="mt-1 lg:mt-0 font-bold text-ink">{formatCurrency(item.monthlyPrice)}</p>
                </div>
                <div>
                  <span className="lg:hidden text-xs font-bold uppercase tracking-wide text-slate-500">Location</span>
                  <p className="mt-1 lg:mt-0 font-semibold text-harbor">{item.location}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
