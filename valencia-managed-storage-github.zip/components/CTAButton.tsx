import Link from "next/link";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { ArrowRight } from "lucide-react";

type CTAButtonProps = {
  href: string;
  children: ReactNode;
  variant?: "primary" | "secondary" | "outline" | "ghost";
  icon?: boolean;
  className?: string;
} & Omit<ComponentPropsWithoutRef<typeof Link>, "href" | "className" | "children">;

const variants = {
  primary:
    "bg-harbor text-white shadow-soft hover:bg-[#12646c] focus-visible:outline-harbor",
  secondary:
    "bg-clay text-white shadow-soft hover:bg-[#a95731] focus-visible:outline-clay",
  outline:
    "border border-slate-300 bg-white text-ink hover:border-harbor hover:text-harbor focus-visible:outline-harbor",
  ghost:
    "text-harbor hover:bg-harbor/10 focus-visible:outline-harbor"
};

export function CTAButton({
  href,
  children,
  variant = "primary",
  icon = true,
  className = "",
  ...props
}: CTAButtonProps) {
  return (
    <Link
      href={href}
      className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 ${variants[variant]} ${className}`}
      {...props}
    >
      <span>{children}</span>
      {icon ? <ArrowRight aria-hidden="true" className="h-4 w-4" /> : null}
    </Link>
  );
}
