"use client";

import { FormEvent, useState } from "react";
import { CheckCircle2, Send } from "lucide-react";

type ContactFormState = {
  name: string;
  email: string;
  phone: string;
  message: string;
};

const initialContactState: ContactFormState = {
  name: "",
  email: "",
  phone: "",
  message: ""
};

const inputClass =
  "mt-2 min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-base text-ink outline-none transition placeholder:text-slate-400 focus:border-harbor focus:ring-2 focus:ring-harbor/20";

export function ContactForm() {
  const [formData, setFormData] = useState<ContactFormState>(initialContactState);
  const [submitted, setSubmitted] = useState(false);

  const updateField = (field: keyof ContactFormState, value: string) => {
    setFormData((current) => ({ ...current, [field]: value }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    console.log("MVP contact request", formData);
    setSubmitted(true);
    setFormData(initialContactState);
  };

  return (
    <form onSubmit={handleSubmit} className="rounded-lg border border-slate-200 bg-white p-5 shadow-soft sm:p-6">
      {submitted ? (
        <div
          role="status"
          className="mb-6 flex items-start gap-3 rounded-lg border border-harbor/20 bg-harbor/10 p-4 text-sm leading-6 text-ink"
        >
          <CheckCircle2 aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-harbor" />
          <p>Thanks. Your message has been recorded for MVP testing.</p>
        </div>
      ) : null}

      <div className="grid gap-5 sm:grid-cols-2">
        <label className="text-sm font-bold text-ink">
          Name
          <input
            required
            value={formData.name}
            onChange={(event) => updateField("name", event.target.value)}
            className={inputClass}
            autoComplete="name"
            name="name"
            type="text"
          />
        </label>

        <label className="text-sm font-bold text-ink">
          Email
          <input
            required
            value={formData.email}
            onChange={(event) => updateField("email", event.target.value)}
            className={inputClass}
            autoComplete="email"
            name="email"
            type="email"
          />
        </label>

        <label className="text-sm font-bold text-ink sm:col-span-2">
          Phone / WhatsApp
          <input
            value={formData.phone}
            onChange={(event) => updateField("phone", event.target.value)}
            className={inputClass}
            autoComplete="tel"
            name="phone"
            type="tel"
          />
        </label>
      </div>

      <label className="mt-6 block text-sm font-bold text-ink">
        Message
        <textarea
          required
          value={formData.message}
          onChange={(event) => updateField("message", event.target.value)}
          className={`${inputClass} min-h-32 resize-y`}
          name="message"
          placeholder="Tell us what you need to store or ask a question."
        />
      </label>

      <button
        type="submit"
        className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-harbor px-5 py-3 text-base font-bold text-white shadow-soft transition hover:bg-[#12646c] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-harbor sm:w-auto"
      >
        <Send aria-hidden="true" className="h-5 w-5" />
        Send message
      </button>
    </form>
  );
}
