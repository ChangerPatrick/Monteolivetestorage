import { Ban } from "lucide-react";
import { prohibitedItems } from "@/data/storage";

export function ProhibitedItems() {
  return (
    <section className="rounded-lg border border-clay/25 bg-clay/5 p-5">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white text-clay">
          <Ban aria-hidden="true" className="h-5 w-5" />
        </span>
        <div>
          <h2 className="text-xl font-bold text-ink">Prohibited items</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            For safety and compliance, these items are not accepted unless a separate written agreement applies.
          </p>
        </div>
      </div>
      <ul className="mt-5 grid gap-2 text-sm text-slate-700 sm:grid-cols-2 lg:grid-cols-3">
        {prohibitedItems.map((item) => (
          <li key={item} className="rounded-md bg-white px-3 py-2">
            {item}
          </li>
        ))}
      </ul>
    </section>
  );
}
