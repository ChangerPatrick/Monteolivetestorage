import { CalendarClock, Camera, ClipboardList, ShieldAlert, Truck } from "lucide-react";
import { trustBadges } from "@/data/storage";

const icons = [ClipboardList, Camera, CalendarClock, Truck, ShieldAlert];

export function TrustBadges() {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
      {trustBadges.map((badge, index) => {
        const Icon = icons[index] ?? ClipboardList;
        return (
          <div
            key={badge.label}
            className="flex min-h-24 items-start gap-3 rounded-lg border border-slate-200 bg-white p-4 shadow-sm"
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-harbor/10 text-harbor">
              <Icon aria-hidden="true" className="h-5 w-5" />
            </span>
            <span>
              <span className="block text-sm font-bold text-ink">{badge.label}</span>
              <span className="mt-1 block text-xs leading-5 text-slate-500">{badge.spanishLabel}</span>
            </span>
          </div>
        );
      })}
    </div>
  );
}
