import Image from "next/image";
import { Box, ClipboardCheck, Truck } from "lucide-react";
import { CTAButton } from "@/components/CTAButton";

export function Hero() {
  return (
    <section className="relative isolate min-h-[78svh] overflow-hidden bg-mist">
      <Image
        src="/storage-hub-hero.png"
        alt="Organized managed storage hub with labeled boxes, shelves, and pickup vehicle"
        fill
        priority
        sizes="100vw"
        className="object-cover"
      />
      <div className="absolute inset-0 bg-white/78" />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(255,255,255,0.98)_0%,rgba(255,255,255,0.88)_45%,rgba(255,255,255,0.52)_100%)]" />

      <div className="relative mx-auto flex min-h-[78svh] max-w-7xl items-center px-4 py-16 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <p className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-bold text-harbor shadow-sm">
            <ClipboardCheck aria-hidden="true" className="h-4 w-4" />
            Managed item custody in Valencia
          </p>
          <h1 className="mt-6 text-4xl font-bold tracking-normal text-ink sm:text-5xl lg:text-6xl">
            Managed storage for homes and small businesses in Valencia
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-700">
            We collect, photograph, label, store, and return your items. No need to rent a full trastero.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <CTAButton href="/quote" className="w-full sm:w-auto">
              Get storage quote
            </CTAButton>
            <CTAButton href="/pricing" variant="outline" className="w-full sm:w-auto">
              See pricing
            </CTAButton>
          </div>

          <div className="mt-10 grid gap-3 sm:grid-cols-3">
            <div className="flex items-center gap-3 rounded-lg bg-white/90 p-3 shadow-sm">
              <Box aria-hidden="true" className="h-5 w-5 text-clay" />
              <span className="text-sm font-semibold text-ink">Boxes, bikes, stock, furniture</span>
            </div>
            <div className="flex items-center gap-3 rounded-lg bg-white/90 p-3 shadow-sm">
              <ClipboardCheck aria-hidden="true" className="h-5 w-5 text-clay" />
              <span className="text-sm font-semibold text-ink">Photo inventory and labels</span>
            </div>
            <div className="flex items-center gap-3 rounded-lg bg-white/90 p-3 shadow-sm">
              <Truck aria-hidden="true" className="h-5 w-5 text-clay" />
              <span className="text-sm font-semibold text-ink">Pickup and return options</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
