"use client";

import { Camera, RotateCcw, Truck } from "lucide-react";
import { useMemo, useState } from "react";
import { StatusBadge } from "@/components/StatusBadge";
import { storedInventoryItems, type ItemStatus } from "@/data/storage";

const demoCustomerName = "Sofia Navarro";

const photoToneStyles = {
  harbor: "bg-harbor/15 text-harbor",
  clay: "bg-clay/15 text-clay",
  citrus: "bg-citrus/25 text-ink",
  olive: "bg-olive/15 text-olive",
  slate: "bg-slate-100 text-slate-700"
};

const formatCurrency = (value: number) =>
  new Intl.NumberFormat("en-IE", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0
  }).format(value);

export function MyItemsDemo() {
  const [requestedIds, setRequestedIds] = useState<string[]>([]);
  const [notice, setNotice] = useState("");

  const demoItems = useMemo(() => {
    return storedInventoryItems
      .filter((item) => item.customerName === demoCustomerName)
      .map((item) => {
        const requested = requestedIds.includes(item.id);
        return {
          ...item,
          status: requested ? "Return requested" as ItemStatus : item.status
        };
      });
  }, [requestedIds]);

  const activeMonthlyTotal = demoItems
    .filter((item) => item.status !== "Returned")
    .reduce((total, item) => total + item.monthlyPrice, 0);

  const requestReturn = (itemId: string, itemName: string) => {
    setRequestedIds((current) => (current.includes(itemId) ? current : [...current, itemId]));
    setNotice(`Return request recorded for ${itemName}. This is a front-end demo only.`);
    console.log("MVP return request", { itemId, itemName, customerName: demoCustomerName });
  };

  return (
    <div className="space-y-8">
      {notice ? (
        <div
          role="status"
          className="rounded-lg border border-harbor/20 bg-harbor/10 p-4 text-sm font-semibold leading-6 text-ink"
        >
          {notice}
        </div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-sm font-semibold text-slate-500">Customer demo</p>
          <p className="mt-2 text-2xl font-bold text-ink">{demoCustomerName}</p>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-sm font-semibold text-slate-500">Stored items</p>
          <p className="mt-2 text-3xl font-bold text-ink">{demoItems.length}</p>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-sm font-semibold text-slate-500">Active monthly cost</p>
          <p className="mt-2 text-3xl font-bold text-ink">{formatCurrency(activeMonthlyTotal)}</p>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        {demoItems.map((item) => {
          const isReturned = item.status === "Returned";
          const isRequested = item.status === "Return requested";

          return (
            <article key={item.id} className="flex h-full flex-col rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
              <div
                className={`flex aspect-[4/3] items-center justify-center rounded-lg ${photoToneStyles[item.photoTone]}`}
              >
                <div className="text-center">
                  <Camera aria-hidden="true" className="mx-auto h-9 w-9" />
                  <p className="mt-3 text-sm font-bold">{item.photoLabel}</p>
                  <p className="mt-1 text-xs font-semibold opacity-75">{item.id}</p>
                </div>
              </div>

              <div className="mt-5 flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-ink">{item.itemName}</h2>
                  <p className="mt-1 text-sm font-semibold text-harbor">{item.itemType}</p>
                </div>
                <StatusBadge status={item.status} />
              </div>

              <dl className="mt-5 grid gap-3 text-sm text-slate-700">
                <div className="flex items-center justify-between gap-3 rounded-md bg-mist px-3 py-2">
                  <dt className="font-semibold">Storage start</dt>
                  <dd>{item.storageStartDate}</dd>
                </div>
                <div className="flex items-center justify-between gap-3 rounded-md bg-mist px-3 py-2">
                  <dt className="font-semibold">Monthly cost</dt>
                  <dd className="font-bold text-ink">{formatCurrency(item.monthlyPrice)}</dd>
                </div>
                <div className="flex items-center justify-between gap-3 rounded-md bg-mist px-3 py-2">
                  <dt className="font-semibold">Hub location</dt>
                  <dd className="font-bold text-harbor">{item.location}</dd>
                </div>
              </dl>

              {item.returnWindow ? (
                <p className="mt-4 rounded-md bg-clay/10 p-3 text-sm font-semibold leading-6 text-clay">
                  {item.returnWindow}
                </p>
              ) : null}

              <button
                type="button"
                disabled={isReturned || isRequested}
                onClick={() => requestReturn(item.id, item.itemName)}
                className="mt-5 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-harbor px-4 py-3 text-sm font-bold text-white transition hover:bg-[#12646c] disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-500"
              >
                {isRequested ? (
                  <>
                    <Truck aria-hidden="true" className="h-4 w-4" />
                    Return requested
                  </>
                ) : isReturned ? (
                  <>
                    <RotateCcw aria-hidden="true" className="h-4 w-4" />
                    Already returned
                  </>
                ) : (
                  <>
                    <Truck aria-hidden="true" className="h-4 w-4" />
                    Request return
                  </>
                )}
              </button>
            </article>
          );
        })}
      </section>
    </div>
  );
}
