import { ChevronDown } from "lucide-react";
import type { FAQ } from "@/data/storage";

type FAQAccordionProps = {
  faqs: FAQ[];
};

export function FAQAccordion({ faqs }: FAQAccordionProps) {
  return (
    <div className="grid gap-3">
      {faqs.map((faq, index) => (
        <details
          key={faq.question}
          className="group rounded-lg border border-slate-200 bg-white p-5 shadow-sm"
          open={index === 0}
        >
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-left text-base font-bold text-ink">
            <span>{faq.question}</span>
            <ChevronDown
              aria-hidden="true"
              className="h-5 w-5 shrink-0 text-harbor transition group-open:rotate-180"
            />
          </summary>
          <p className="mt-4 text-sm leading-6 text-slate-600">{faq.answer}</p>
        </details>
      ))}
    </div>
  );
}
