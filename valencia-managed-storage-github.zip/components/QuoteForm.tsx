"use client";

import { FormEvent, useState } from "react";
import { CheckCircle2, Mail, MessageCircle, Send } from "lucide-react";
import { expectedDurations, itemTypes, storagePurposes } from "@/data/storage";
import {
  createQuoteEmailHref,
  createQuoteWhatsappHref
} from "@/src/lib/quoteLinks";
import { adminName } from "@/src/lib/siteConfig";

type QuoteFormState = {
  name: string;
  email: string;
  phone: string;
  neighborhood: string;
  purpose: string;
  items: string[];
  quantity: string;
  pickup: "Yes" | "No" | "Not sure";
  startDate: string;
  duration: string;
  message: string;
};

const initialFormState: QuoteFormState = {
  name: "",
  email: "",
  phone: "",
  neighborhood: "",
  purpose: "",
  items: [],
  quantity: "",
  pickup: "Not sure",
  startDate: "",
  duration: "",
  message: ""
};

const inputClass =
  "mt-2 min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-base text-ink outline-none transition placeholder:text-slate-400 focus:border-harbor focus:ring-2 focus:ring-harbor/20";

const labelClass = "text-sm font-bold text-ink";

export function QuoteForm() {
  const [formData, setFormData] = useState<QuoteFormState>(initialFormState);
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [submittedQuote, setSubmittedQuote] = useState<QuoteFormState | null>(null);

  const updateField = (field: keyof QuoteFormState, value: string) => {
    setFormData((current) => ({ ...current, [field]: value }));
  };

  const toggleItem = (item: string) => {
    setFormData((current) => {
      const exists = current.items.includes(item);
      return {
        ...current,
        items: exists ? current.items.filter((value) => value !== item) : [...current.items, item]
      };
    });
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (formData.items.length === 0) {
      setError("Please select at least one item type.");
      setSubmitted(false);
      return;
    }

    const quoteRequest = {
      ...formData,
      items: [...formData.items]
    };

    setError("");
    setSubmitted(true);
    setSubmittedQuote(quoteRequest);
    console.log("MVP quote request", quoteRequest);
    setFormData(initialFormState);
  };

  return (
    <form onSubmit={handleSubmit} className="rounded-lg border border-slate-200 bg-white p-5 shadow-soft sm:p-6">
      {submitted ? (
        <div
          role="status"
          className="mb-6 flex items-start gap-3 rounded-lg border border-harbor/20 bg-harbor/10 p-4 text-sm leading-6 text-ink"
        >
          <CheckCircle2 aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-harbor" />
          <div>
            <p>
              Thank you. Your storage request has been received. {adminName} will contact you by WhatsApp or email.
            </p>
            {submittedQuote ? (
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <a
                  href={createQuoteWhatsappHref(submittedQuote)}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-[#25d366] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#1fb45a]"
                >
                  <MessageCircle aria-hidden="true" className="h-4 w-4" />
                  Send request by WhatsApp
                </a>
                <a
                  href={createQuoteEmailHref(submittedQuote)}
                  className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-slate-300 bg-white px-4 py-3 text-sm font-bold text-ink transition hover:border-harbor hover:text-harbor"
                >
                  <Mail aria-hidden="true" className="h-4 w-4" />
                  Send request by email
                </a>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      {error ? (
        <p role="alert" className="mb-6 rounded-lg border border-clay/25 bg-clay/10 p-4 text-sm font-semibold text-clay">
          {error}
        </p>
      ) : null}

      <p className="mb-6 rounded-lg border border-harbor/20 bg-harbor/10 p-4 text-sm font-semibold leading-6 text-ink">
        Your request will be sent to {adminName}, the storage manager.
      </p>

      <div className="grid gap-5 sm:grid-cols-2">
        <label className={labelClass}>
          Name
          <input
            required
            value={formData.name}
            onChange={(event) => updateField("name", event.target.value)}
            className={inputClass}
            autoComplete="name"
            name="name"
            type="text"
          />
        </label>

        <label className={labelClass}>
          Email
          <input
            required
            value={formData.email}
            onChange={(event) => updateField("email", event.target.value)}
            className={inputClass}
            autoComplete="email"
            name="email"
            type="email"
          />
        </label>

        <label className={labelClass}>
          Phone / WhatsApp
          <input
            required
            value={formData.phone}
            onChange={(event) => updateField("phone", event.target.value)}
            className={inputClass}
            autoComplete="tel"
            name="phone"
            type="tel"
          />
        </label>

        <label className={labelClass}>
          Neighborhood in Valencia
          <input
            required
            value={formData.neighborhood}
            onChange={(event) => updateField("neighborhood", event.target.value)}
            className={inputClass}
            name="neighborhood"
            placeholder="Monteolivete, Ruzafa, Malilla..."
            type="text"
          />
        </label>

        <label className={labelClass}>
          Storage purpose
          <select
            required
            value={formData.purpose}
            onChange={(event) => updateField("purpose", event.target.value)}
            className={inputClass}
            name="purpose"
          >
            <option value="">Select purpose</option>
            {storagePurposes.map((purpose) => (
              <option key={purpose} value={purpose}>
                {purpose}
              </option>
            ))}
          </select>
        </label>

        <label className={labelClass}>
          Approximate quantity
          <input
            required
            value={formData.quantity}
            onChange={(event) => updateField("quantity", event.target.value)}
            className={inputClass}
            min="1"
            name="quantity"
            placeholder="Example: 8 boxes, 1 bike"
            type="text"
          />
        </label>
      </div>

      <fieldset className="mt-6">
        <legend className={labelClass}>Items to store</legend>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {itemTypes.map((item) => (
            <label
              key={item}
              className="flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-mist px-3 py-2 text-sm font-semibold text-ink"
            >
              <input
                type="checkbox"
                checked={formData.items.includes(item)}
                onChange={() => toggleItem(item)}
                className="h-4 w-4 rounded border-slate-300 text-harbor focus:ring-harbor"
              />
              {item}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset className="mt-6">
        <legend className={labelClass}>Need pickup?</legend>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          {(["Yes", "No", "Not sure"] as const).map((option) => (
            <label
              key={option}
              className="flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-mist px-3 py-2 text-sm font-semibold text-ink"
            >
              <input
                type="radio"
                name="pickup"
                checked={formData.pickup === option}
                onChange={() => updateField("pickup", option)}
                className="h-4 w-4 border-slate-300 text-harbor focus:ring-harbor"
              />
              {option}
            </label>
          ))}
        </div>
      </fieldset>

      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        <label className={labelClass}>
          Desired start date
          <input
            required
            value={formData.startDate}
            onChange={(event) => updateField("startDate", event.target.value)}
            className={inputClass}
            inputMode="numeric"
            name="startDate"
            pattern="\d{4}-\d{2}-\d{2}"
            placeholder="2026-06-01"
            title="Use YYYY-MM-DD format"
            type="text"
          />
        </label>

        <label className={labelClass}>
          Expected duration
          <select
            required
            value={formData.duration}
            onChange={(event) => updateField("duration", event.target.value)}
            className={inputClass}
            name="duration"
          >
            <option value="">Select duration</option>
            {expectedDurations.map((duration) => (
              <option key={duration} value={duration}>
                {duration}
              </option>
            ))}
          </select>
        </label>
      </div>

      <label className={`${labelClass} mt-6 block`}>
        Message
        <textarea
          value={formData.message}
          onChange={(event) => updateField("message", event.target.value)}
          className={`${inputClass} min-h-32 resize-y`}
          name="message"
          placeholder="Tell us about access, stairs, lift, item sizes, or preferred contact time."
        />
      </label>

      <button
        type="submit"
        className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-harbor px-5 py-3 text-base font-bold text-white shadow-soft transition hover:bg-[#12646c] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-harbor sm:w-auto"
      >
        <Send aria-hidden="true" className="h-5 w-5" />
        Request exact quote
      </button>
    </form>
  );
}
