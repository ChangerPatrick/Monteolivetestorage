import { MapPin } from "lucide-react";
import { neighborhoods } from "@/data/storage";

export function ServiceAreaList() {
  return (
    <ul className="grid gap-3 sm:grid-cols-2">
      {neighborhoods.map((neighborhood) => (
        <li
          key={neighborhood}
          className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white p-4 text-sm font-semibold text-ink shadow-sm"
        >
          <MapPin aria-hidden="true" className="h-4 w-4 shrink-0 text-clay" />
          {neighborhood}
        </li>
      ))}
    </ul>
  );
}
