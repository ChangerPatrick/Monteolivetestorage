import type { ItemStatus } from "@/data/storage";

type StatusBadgeProps = {
  status: ItemStatus;
};

const statusStyles: Record<ItemStatus, string> = {
  Received: "bg-citrus/20 text-ink",
  Photographed: "bg-harbor/10 text-harbor",
  Labeled: "bg-olive/15 text-olive",
  Stored: "bg-emerald-100 text-emerald-800",
  "Return requested": "bg-clay/15 text-clay",
  Returned: "bg-slate-100 text-slate-700"
};

export function StatusBadge({ status }: StatusBadgeProps) {
  return (
    <span className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${statusStyles[status]}`}>
      {status}
    </span>
  );
}
