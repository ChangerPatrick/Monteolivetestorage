import { Bike, BriefcaseBusiness, GraduationCap, Home, Package, Paintbrush } from "lucide-react";
import type { UseCase } from "@/data/storage";

const iconMap = {
  paintbrush: Paintbrush,
  home: Home,
  graduation: GraduationCap,
  bike: Bike,
  briefcase: BriefcaseBusiness,
  package: Package
};

type UseCaseCardProps = {
  useCase: UseCase;
};

export function UseCaseCard({ useCase }: UseCaseCardProps) {
  const Icon = iconMap[useCase.icon];

  return (
    <article className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-soft">
      <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-olive/15 text-olive">
        <Icon aria-hidden="true" className="h-5 w-5" />
      </span>
      <h3 className="mt-5 text-lg font-bold text-ink">{useCase.title}</h3>
      <p className="mt-1 text-sm font-semibold text-harbor">{useCase.spanishLabel}</p>
      <p className="mt-3 text-sm leading-6 text-slate-600">{useCase.description}</p>
    </article>
  );
}
