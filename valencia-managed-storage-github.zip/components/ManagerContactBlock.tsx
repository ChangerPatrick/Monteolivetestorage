import { Mail, MessageCircle, UserRound } from "lucide-react";
import {
  adminEmail,
  adminName,
  adminPhoneDisplay
} from "@/src/lib/siteConfig";
import {
  createGeneralEmailHref,
  createGeneralWhatsappHref
} from "@/src/lib/quoteLinks";

type ManagerContactBlockProps = {
  compact?: boolean;
};

export function ManagerContactBlock({ compact = false }: ManagerContactBlockProps) {
  return (
    <div className="rounded-lg border border-harbor/20 bg-white p-5 shadow-sm">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-harbor/10 text-harbor">
          <UserRound aria-hidden="true" className="h-5 w-5" />
        </span>
        <div>
          <h2 className="text-xl font-bold text-ink">Quote manager</h2>
          <p className="mt-2 text-base font-bold text-ink">{adminName}</p>
          <p className="mt-1 text-sm leading-6 text-slate-600">
            Email:{" "}
            <a className="font-semibold text-harbor hover:underline" href={`mailto:${adminEmail}`}>
              {adminEmail}
            </a>
          </p>
          <p className="text-sm leading-6 text-slate-600">WhatsApp: {adminPhoneDisplay}</p>
        </div>
      </div>

      <div className={`mt-5 grid gap-3 ${compact ? "" : "sm:grid-cols-2"}`}>
        <a
          href={createGeneralWhatsappHref()}
          target="_blank"
          rel="noreferrer"
          className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-[#25d366] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#1fb45a]"
        >
          <MessageCircle aria-hidden="true" className="h-4 w-4" />
          Send request by WhatsApp
        </a>
        <a
          href={createGeneralEmailHref()}
          className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-slate-300 bg-white px-4 py-3 text-sm font-bold text-ink transition hover:border-harbor hover:text-harbor"
        >
          <Mail aria-hidden="true" className="h-4 w-4" />
          Send request by email
        </a>
      </div>
    </div>
  );
}
