import {
  adminName,
  adminPhoneWhatsapp,
  defaultQuoteRecipient
} from "@/src/lib/siteConfig";

export type QuoteRequestDetails = {
  name: string;
  email: string;
  phone: string;
  neighborhood: string;
  purpose: string;
  items: string[];
  quantity: string;
  pickup: string;
  startDate: string;
  duration: string;
  message: string;
};

export function formatQuoteRequestBody(details: QuoteRequestDetails) {
  return [
    "New storage quote request",
    "",
    `Customer name: ${details.name}`,
    `Phone / WhatsApp: ${details.phone}`,
    `Email: ${details.email}`,
    `Neighborhood: ${details.neighborhood}`,
    `Storage purpose: ${details.purpose}`,
    `Items to store: ${details.items.join(", ") || "Not specified"}`,
    `Approximate quantity: ${details.quantity}`,
    `Pickup required: ${details.pickup}`,
    `Desired start date: ${details.startDate}`,
    `Expected duration: ${details.duration}`,
    `Message: ${details.message || "No extra message"}`,
    "",
    `Quote manager: ${adminName}`
  ].join("\n");
}

export function createQuoteWhatsappHref(details: QuoteRequestDetails) {
  return `https://wa.me/${adminPhoneWhatsapp}?text=${encodeURIComponent(formatQuoteRequestBody(details))}`;
}

export function createQuoteEmailHref(details: QuoteRequestDetails) {
  const subject = encodeURIComponent("New storage quote request");
  const body = encodeURIComponent(formatQuoteRequestBody(details));

  return `mailto:${defaultQuoteRecipient}?subject=${subject}&body=${body}`;
}

export function createGeneralWhatsappHref() {
  const message = `Hello ${adminName}, I would like to ask about managed storage in Valencia.`;

  return `https://wa.me/${adminPhoneWhatsapp}?text=${encodeURIComponent(message)}`;
}

export function createGeneralEmailHref() {
  const subject = encodeURIComponent("Managed storage enquiry");
  const body = encodeURIComponent(
    `Hello ${adminName},\n\nI would like to ask about managed storage in Valencia.\n\nThank you.`
  );

  return `mailto:${defaultQuoteRecipient}?subject=${subject}&body=${body}`;
}
