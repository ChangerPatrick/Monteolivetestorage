export const businessName = "Valencia Managed Storage";

export const adminName = "Zhanel Shokparova";

export const adminEmail = "Shokparova.zhanel@gmail.com";

export const adminPhoneDisplay = "+34 653 539 906";

export const adminPhoneWhatsapp = "34653539906";

export const serviceArea = [
  "Monteolivete",
  "Quatre Carreres",
  "Ruzafa",
  "En Corts",
  "Malilla",
  "Gran Vía",
  "City of Arts and Sciences area",
  "Central Valencia"
];

export const defaultQuoteRecipient = adminEmail;
